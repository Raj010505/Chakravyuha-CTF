#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void stage1() {
    char input[32];
    printf("Stage 1: Enter the magic word!\n> ");
    fflush(stdout);
    fgets(input, sizeof(input), stdin);
    if (strncmp(input, "hunter\n", 7) == 0) {
        printf("Correct! Moving to Stage 2...\n");
    } else {
        printf("Wrong! Try harder.\n");
        exit(1);
    }
}

void stage2() {
    int num;
    printf("Stage 2: Enter the lucky number!\n> ");
    fflush(stdout);
    scanf("%d", &num);
    if (num == 1337) {
        printf("Great! Moving to Stage 3...\n");
    } else {
        printf("Wrong! Exiting...\n");
        exit(1);
    }
}

void stage3() {
    char buffer[32];
    printf("Stage 3: Buffer Challenge! Overflow me?\n> ");
    fflush(stdout);
    gets(buffer);
}

void win() {
    printf("Congratulations! Here is your flag: G8KEY{JINW00_RANK_E_HUNTER}\n");
    fflush(stdout);
    exit(0);
}

int main() {
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    
    printf("Welcome to the Binary Gauntlet! Complete all stages to win.\n");
    stage1();
    stage2();
    stage3();
    return 0;
}
